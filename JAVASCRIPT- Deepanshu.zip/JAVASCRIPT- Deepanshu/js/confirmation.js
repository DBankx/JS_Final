$(document).ready(function() {
    // display date from session storage
    $("#email").text( sessionStorage.email );
    
}); // end of ready()